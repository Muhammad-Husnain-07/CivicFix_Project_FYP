# CivicFix > 2024-11-23 12:46am
https://universe.roboflow.com/civicfixfyp/civicfix-x71zo

Provided by a Roboflow user
License: CC BY 4.0

